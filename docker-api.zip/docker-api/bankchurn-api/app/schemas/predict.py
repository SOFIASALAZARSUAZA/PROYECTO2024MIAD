from typing import Any, List, Optional, Dict
from pydantic import BaseModel
from model.processing.validation import DataInputSchema as ValidationDataInputSchema



# Esquema para inputs múltiples
class DataInputSchema(BaseModel):
    ALUMINIO_RESIDUAL_MG_L_AL_BN: Optional[float] = None
    CLORUROS_MG_L_CL_BN: Optional[float] = None
    SULFATOS_MG_L_SO4_BN: Optional[float] = None
    CONDUCTIVIDAD_US_CM_BN: Optional[float] = None
    OXIGENO_DISUELTO_MG_L_O2_BN: Optional[float] = None
    HIERRO_TOTAL_MG_L_FE_3_BN: Optional[float] = None
    TEMPERATURA_C_BN: Optional[float] = None
    NITRATOS_MG_L_NO3_BN: Optional[float] = None
    NITROGENO_AMONIACAL_G_L_BN: Optional[float] = None
    NITRITOS_MG_L_NO2_BN: Optional[float] = None
    MANGANESOS_MG_L_MN_BN: Optional[float] = None
    COT_MG_L_BN: Optional[float] = None
    ALCALINIDAD_TOTAL_MG_L_CACO3_BN: Optional[float] = None
    COLOR_UPC_BN: Optional[float] = None
    DUREZA_TOTAL_MG_L_CACO3_BN: Optional[float] = None
    MATERIA_ORGANICA_MG_L_BN: Optional[float] = None
    TURBIEDAD_UNT_BN: Optional[float] = None
    PH_BN: Optional[float] = None
    POTENCIAL_REDOX_MV_BN: Optional[float] = None
    DUREZA_CALCICA_MG_L_CACO3_BN: Optional[float] = None
    FOSFATOS_MG_L_BN: Optional[float] = None
    POTENCIAL_REDOX_MV_CRU: Optional[float] = None
    SULFATOS_MG_L_SO4_CRU: Optional[float] = None
    SOLIDOS_SUSPENDIDOS_MG_L_CRU: Optional[float] = None
    COT_MG_L_CRU: Optional[float] = None
    ALCALINIDAD_TOTAL_MG_L_CACO3_CRU: Optional[float] = None
    DUREZA_CALCICA_MG_L_CACO3_CRU: Optional[float] = None
    MANGANESOS_MG_L_MN_CRU: Optional[float] = None
    OXIGENO_DISUELTO_MG_L_O2_CRU: Optional[float] = None
    NITRATOS_MG_L_NO3_CRU: Optional[float] = None
    MATERIA_ORGANICA_MG_L_CRU: Optional[float] = None
    CONDUCTIVIDAD_US_CM_CRU: Optional[float] = None
    NITROGENO_AMONIACAL_G_L_CRU: Optional[float] = None
    TEMPERATURA_C_CRU: Optional[float] = None
    TURBIEDAD_UNT_CRU: Optional[float] = None
    NITRITOS_MG_L_NO2_CRU: Optional[float] = None
    FOSFATOS_MG_L_CRU: Optional[float] = None
    DUREZA_TOTAL_MG_L_CACO3_CRU: Optional[float] = None
    COLOR_UPC_CRU: Optional[float] = None
    CLORUROS_MG_L_CL_CRU: Optional[float] = None
    ALUMINIO_RESIDUAL_MG_L_AL_CRU: Optional[float] = None
    HIERRO_TOTAL_MG_L_FE_3_CRU: Optional[float] = None
    PH_CRU: Optional[float] = None
    CLORO_LIBRE_MG_L_CL2_MEZ: Optional[float] = None
    TEMPERATURA_C_MEZ: Optional[float] = None
    PH_MEZ: Optional[float] = None
    CLORO_COMBINADO_MG_L_CL2_MEZ: Optional[float] = None
    CLORO_TOTAL_MG_L_CL2_MEZ: Optional[float] = None
    OXIGENO_DISUELTO_MG_L_O2_MEZ: Optional[float] = None

# Esquema para recibir múltiples entradas
class MultipleDataInputs(BaseModel):
    inputs: List[DataInputSchema]  # Una lista de entradas que contienen todos los parámetros necesarios

    class Config:
        schema_extra = {
            "example": {
                "inputs": [
                    {
                        "ALUMINIO_RESIDUAL_MG_L_AL_BN": 0.15,
      			"CLORUROS_MG_L_CL_BN": 50.3,
      			"SULFATOS_MG_L_SO4_BN": 20.1,
      			"CONDUCTIVIDAD_US_CM_BN": 250.4,
      			"OXIGENO_DISUELTO_MG_L_O2_BN": 8.6,
      			"HIERRO_TOTAL_MG_L_FE_3_BN": 1.2,
      			"TEMPERATURA_C_BN": 25.3,
      			"NITRATOS_MG_L_NO3_BN": 5.8,
      			"NITROGENO_AMONIACAL_G_L_BN": 0.04,
      			"NITRITOS_MG_L_NO2_BN": 0.02,
      			"MANGANESOS_MG_L_MN_BN": 0.1,
      			"COT_MG_L_BN": 0.9,
      			"ALCALINIDAD_TOTAL_MG_L_CACO3_BN": 120.5,
      			"COLOR_UPC_BN": 15.7,
      			"DUREZA_TOTAL_MG_L_CACO3_BN": 200.2,
      			"MATERIA_ORGANICA_MG_L_BN": 30.4,
      			"TURBIEDAD_UNT_BN": 3.2,
      			"PH_BN": 7.3,
      			"POTENCIAL_REDOX_MV_BN": 350.0,
      			"DUREZA_CALCICA_MG_L_CACO3_BN": 150.3,
      			"FOSFATOS_MG_L_BN": 0.1,
      			"POTENCIAL_REDOX_MV_CRU": 320.0,
      			"SULFATOS_MG_L_SO4_CRU": 18.9,
      			"SOLIDOS_SUSPENDIDOS_MG_L_CRU": 12.5,
      			"COT_MG_L_CRU": 1.2,
      			"ALCALINIDAD_TOTAL_MG_L_CACO3_CRU": 125.0,
      			"DUREZA_CALCICA_MG_L_CACO3_CRU": 145.7,
      			"MANGANESOS_MG_L_MN_CRU": 0.08,
      			"OXIGENO_DISUELTO_MG_L_O2_CRU": 7.9,
      			"NITRATOS_MG_L_NO3_CRU": 4.5,
      			"MATERIA_ORGANICA_MG_L_CRU": 32.7,
      			"CONDUCTIVIDAD_US_CM_CRU": 245.0,
      			"NITROGENO_AMONIACAL_G_L_CRU": 0.05,
      			"TEMPERATURA_C_CRU": 26.1,
      			"TURBIEDAD_UNT_CRU": 2.8,
      			"NITRITOS_MG_L_NO2_CRU": 0.03,
      			"FOSFATOS_MG_L_CRU": 0.12,
      			"DUREZA_TOTAL_MG_L_CACO3_CRU": 210.5,
      			"COLOR_UPC_CRU": 16.3,
      			"CLORUROS_MG_L_CL_CRU": 55.7,
      			"ALUMINIO_RESIDUAL_MG_L_AL_CRU": 0.14,
      			"HIERRO_TOTAL_MG_L_FE_3_CRU": 1.1,
      			"PH_CRU": 7.2,
      			"CLORO_LIBRE_MG_L_CL2_MEZ": 1.8,
      			"TEMPERATURA_C_MEZ": 24.8,
      			"PH_MEZ": 7.4,
      			"CLORO_COMBINADO_MG_L_CL2_MEZ": 0.9,
      			"CLORO_TOTAL_MG_L_CL2_MEZ": 2.7,
      			"OXIGENO_DISUELTO_MG_L_O2_MEZ": 9.3
                    }
                ]
            }
        }

# Este modelo representa los resultados de la predicción
class PredictionResults(BaseModel):
    predictions: List[Any]  # Asumiendo que las predicciones son una lista de valores
    errors: Optional[str] = None
    fig_0: Optional[str] = None  # Imagen del gráfico para el clúster 0 en base64
    fig_1: Optional[str] = None

