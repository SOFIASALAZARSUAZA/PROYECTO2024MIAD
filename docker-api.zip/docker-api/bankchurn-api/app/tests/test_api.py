import math

import numpy as np
import pandas as pd
from fastapi.testclient import TestClient



def test_make_prediction(client: TestClient) -> None:
    # Datos de prueba - Asegúrate de incluir todas las variables que el modelo necesita
    payload = {
        "inputs": [
            {
                "MANGANESOS_MG_L_MN_CRU": 0.5,
                "HIERRO_TOTAL_MG_L_FE_3_CRU": 3.2,
                "OXIGENO_DISUELTO_MG_L_O2_CRU": 2.1,
                "CLORO_LIBRE_MG_L_CL2_MEZ": 0.8,
                "CONDUCTIVIDAD_US_CM_BN": 150.5,
                "POTENCIAL_REDOX_MV_BN": 300.0,
                "TEMPERATURA_C_BN": 20.5,
                "ALCALINIDAD_TOTAL_MG_L_CACO3_CRU": 40.0,
                "DUREZA_CALCICA_MG_L_CACO3_CRU": 18.5,
                "DUREZA_TOTAL_MG_L_CACO3_BN": 30.0,
                "OXIGENO_DISUELTO_MG_L_O2_BN": 2.0,
                "POTENCIAL_REDOX_MV_CRU": 280.0,
                "CONDUCTIVIDAD_US_CM_CRU": 140.0,
                "CLORUROS_MG_L_CL_CRU": 25.0,
                "MANGANESOS_MG_L_MN_BN": 0.6,
                "PH_CRU": 7.0,
                "SULFATOS_MG_L_SO4_CRU": 12.0,
                "DUREZA_CALCICA_MG_L_CACO3_BN": 15.0,
                "TURBIEDAD_UNT_BN": 10.0,
                "NITRATOS_MG_L_NO3_BN": 5.0,
                "ALCALINIDAD_TOTAL_MG_L_CACO3_BN": 35.0,
                "FOSFATOS_MG_L_CRU": 1.5,
                "DUREZA_TOTAL_MG_L_CACO3_CRU": 38.0,
                "SULFATOS_MG_L_SO4_BN": 8.0,
                "PH_MEZ": 7.5,
                "ALUMINIO_RESIDUAL_MG_L_AL_BN": 0.01,
                "SOLIDOS_SUSPENDIDOS_MG_L_CRU": 50.0,
                "PH_BN": 7.8,
                "COLOR_UPC_BN": 200.0,
                "FOSFATOS_MG_L_BN": 1.2,
                "NITRATOS_MG_L_NO3_CRU": 8.0,
                "TEMPERATURA_C_CRU": 18.0,
                "HIERRO_TOTAL_MG_L_FE_3_BN": 2.5,
                "OXIGENO_DISUELTO_MG_L_O2_MEZ": 3.0,
                "CLORO_TOTAL_MG_L_CL2_MEZ": 1.0,
                "TEMPERATURA_C_MEZ": 22.0,
                "NITROGENO_AMONIACAL_G_L_BN": 0.5,
                "COT_MG_L_CRU": 6.0,
                "CLORO_COMBINADO_MG_L_CL2_MEZ": 0.5,
                "ALUMINIO_RESIDUAL_MG_L_AL_CRU": 0.02,
                "COT_MG_L_BN": 5.5,
                "COLOR_UPC_CRU": 250.0,
                "NITRITOS_MG_L_NO2_CRU": 20.0,
                "NITROGENO_AMONIACAL_G_L_CRU": 0.7,
                "TURBIEDAD_UNT_CRU": 15.0,
                "MATERIA_ORGANICA_MG_L_CRU": 4.0,
                "CLORUROS_MG_L_CL_BN": 20.0,
                "NITRITOS_MG_L_NO2_BN": 18.0,
                "MATERIA_ORGANICA_MG_L_BN": 3.5
            }
        ]
    }
    # When
    response = client.post(
        "http://localhost:8001/api/v1/predict",
        json=payload,
    )

    # Then
    assert response.status_code == 200
    prediction_data = response.json()
    assert prediction_data["predictions"]
    assert prediction_data["errors"] is None
    assert math.isclose(prediction_data["predictions"][0], 113422, rel_tol=100)