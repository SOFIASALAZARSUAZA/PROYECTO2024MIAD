import json
import pickle
import numpy as np
import pandas as pd
import base64
from fastapi import APIRouter, HTTPException
from fastapi.encoders import jsonable_encoder
from loguru import logger
from model import __version__ as model_version
from model.predict import make_prediction
from sklearn.preprocessing import StandardScaler
import plotly.express as px
from app import __version__, schemas
from app.config import settings

feature_names = [
    'ALUMINIO_RESIDUAL_MG_L_AL_BN', 'CLORUROS_MG_L_CL_BN', 'SULFATOS_MG_L_SO4_BN', 
    'CONDUCTIVIDAD_US_CM_BN', 'OXIGENO_DISUELTO_MG_L_O2_BN', 'HIERRO_TOTAL_MG_L_FE_3_BN', 
    'TEMPERATURA_C_BN', 'NITRATOS_MG_L_NO3_BN', 'NITROGENO_AMONIACAL_G_L_BN', 
    'NITRITOS_MG_L_NO2_BN', 'MANGANESOS_MG_L_MN_BN', 'COT_MG_L_BN', 
    'ALCALINIDAD_TOTAL_MG_L_CACO3_BN', 'COLOR_UPC_BN', 'DUREZA_TOTAL_MG_L_CACO3_BN', 
    'MATERIA_ORGANICA_MG_L_BN', 'TURBIEDAD_UNT_BN', 'PH_BN', 'POTENCIAL_REDOX_MV_BN', 
    'DUREZA_CALCICA_MG_L_CACO3_BN', 'FOSFATOS_MG_L_BN', 'POTENCIAL_REDOX_MV_CRU', 
    'SULFATOS_MG_L_SO4_CRU', 'SOLIDOS_SUSPENDIDOS_MG_L_CRU', 'COT_MG_L_CRU', 
    'ALCALINIDAD_TOTAL_MG_L_CACO3_CRU', 'DUREZA_CALCICA_MG_L_CACO3_CRU', 
    'MANGANESOS_MG_L_MN_CRU', 'OXIGENO_DISUELTO_MG_L_O2_CRU', 'NITRATOS_MG_L_NO3_CRU', 
    'MATERIA_ORGANICA_MG_L_CRU', 'CONDUCTIVIDAD_US_CM_CRU', 'NITROGENO_AMONIACAL_G_L_CRU', 
    'TEMPERATURA_C_CRU', 'TURBIEDAD_UNT_CRU', 'NITRITOS_MG_L_NO2_CRU', 
    'FOSFATOS_MG_L_CRU', 'DUREZA_TOTAL_MG_L_CACO3_CRU', 'COLOR_UPC_CRU', 
    'CLORUROS_MG_L_CL_CRU', 'ALUMINIO_RESIDUAL_MG_L_AL_CRU', 'HIERRO_TOTAL_MG_L_FE_3_CRU', 
    'PH_CRU', 'CLORO_LIBRE_MG_L_CL2_MEZ', 'TEMPERATURA_C_MEZ', 'PH_MEZ', 
    'CLORO_COMBINADO_MG_L_CL2_MEZ', 'CLORO_TOTAL_MG_L_CL2_MEZ', 'OXIGENO_DISUELTO_MG_L_O2_MEZ'
]


# Cargar modelos
with open("/opt/app/modelo_kmeans.pkl", "rb") as f:
    kmeans_model = pickle.load(f)
with open("/opt/app/modelo_random_forest_cluster_0.pkl", "rb") as f:
    model_cluster_0 = pickle.load(f)
with open("/opt/app/modelo_random_forest_cluster_1.pkl", "rb") as f:
    model_cluster_1 = pickle.load(f)

historico_predicciones_0 = []
historico_predicciones_1 = []

api_router = APIRouter()

# Ruta para verificar que la API se esté ejecutando correctamente
@api_router.get("/health", response_model=schemas.Health, status_code=200)
def health() -> dict:
    """
    Verifica el estado de la API y los modelos.
    """
    # Verificar si los modelos están cargados
    models_loaded = all([
        "kmeans_model" in globals(),
        "model_cluster_0" in globals(),
        "model_cluster_1" in globals()
    ])
    
    health = schemas.Health(
        name=settings.PROJECT_NAME,
        api_version=__version__,
        model_version=model_version,
        status="Models loaded" if models_loaded else "Error loading models"
    )

    return health.dict()

# Ruta para realizar las predicciones
@api_router.post("/predict", response_model=schemas.PredictionResults, status_code=200)
async def predict(input_data: schemas.MultipleDataInputs) -> dict:
    # Convertir inputs en DataFrame
    input_df = pd.DataFrame(jsonable_encoder(input_data.inputs))

    # Asegurarse de que las columnas estén en el orden correcto
    input_df = input_df[feature_names]

    # Predicción del clúster
    cluster = kmeans_model.predict(input_df)[0]

    # Predicción por clúster
    if cluster == 0:
        valoresprueba = input_df[model_cluster_0.feature_names_in_]
        prediction = model_cluster_0.predict(valoresprueba)[0]
        historico_predicciones_0.append(prediction)  # Acumular predicción
        fig_0 = px.line(x=list(range(1, len(historico_predicciones_0) + 1)), y=historico_predicciones_0,
                        title="Historial de Predicciones - Clúster 0", labels={'x': 'Número de Predicción', 'y': 'Valor'},
                        color_discrete_sequence=["blue"])
        img_bytes_0 = fig_0.to_image(format="png")
        img_base64_0 = base64.b64encode(img_bytes_0).decode("utf-8")
    else:
        valoresprueba = input_df[model_cluster_1.feature_names_in_]
        prediction = model_cluster_1.predict(valoresprueba)[0]
        historico_predicciones_1.append(prediction)  # Acumular predicción
        fig_1 = px.line(x=list(range(1, len(historico_predicciones_1) + 1)), y=historico_predicciones_1,
                        title="Historial de Predicciones - Clúster 1", labels={'x': 'Número de Predicción', 'y': 'Valor'},
                        color_discrete_sequence=["blue"])
        img_bytes_1 = fig_1.to_image(format="png")
        img_base64_1 = base64.b64encode(img_bytes_1).decode("utf-8")

    return {
        "errors": None,
        "predictions": [prediction],
        "fig_0": img_base64_0 if cluster == 0 else None,
        "fig_1": img_base64_1 if cluster == 1 else None
    }